/**
 * FORTUNE ENHANCE - Efeitos Sonoros (Web Audio Synth), Vibração Háptica e Partículas
 */
(function () {
  let audioCtx = null;
  let soundEnabled = true;

  function initAudio() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Tocar som sintetizado (sem dependência de arquivos externos)
  function playBeep(freq = 440, type = 'sine', duration = 0.1, gainVal = 0.15) {
    if (!soundEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(gainVal, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  window.FortuneAudio = {
    click: function () {
      playBeep(600, 'sine', 0.05, 0.08);
      FortuneAudio.vibrate(10);
    },
    coin: function () {
      playBeep(987, 'sine', 0.08, 0.12);
      setTimeout(() => playBeep(1318, 'sine', 0.15, 0.15), 50);
      FortuneAudio.vibrate([15, 30, 20]);
    },
    spin: function () {
      playBeep(220, 'triangle', 0.08, 0.1);
      FortuneAudio.vibrate(15);
    },
    win: function () {
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        setTimeout(() => playBeep(freq, 'triangle', 0.2, 0.2), idx * 80);
      });
      FortuneAudio.vibrate([30, 40, 50, 40, 60]);
    },
    bigWin: function () {
      const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
      notes.forEach((freq, idx) => {
        setTimeout(() => playBeep(freq, 'square', 0.25, 0.18), idx * 70);
      });
      FortuneAudio.vibrate([50, 50, 50, 50, 100]);
    },
    vibrate: function (pattern = 20) {
      if (navigator.vibrate && soundEnabled) {
        try {
          navigator.vibrate(pattern);
        } catch (e) {}
      }
    },
    toggleSound: function () {
      soundEnabled = !soundEnabled;
      const btn = document.getElementById('soundBtn');
      if (btn) {
        btn.textContent = soundEnabled ? '🔊' : '🔇';
      }
      localStorage.setItem('fortunego_sound', soundEnabled ? '1' : '0');
      return soundEnabled;
    },
    isSoundEnabled: function () {
      return soundEnabled;
    }
  };

  // Carregar preferência salva
  const saved = localStorage.getItem('fortunego_sound');
  if (saved !== null) {
    soundEnabled = saved === '1';
  }

  // Desbloqueia contexto de áudio no primeiro clique do usuário
  document.addEventListener('pointerdown', function unlock() {
    initAudio();
    document.removeEventListener('pointerdown', unlock);
  }, { once: true });
})();
