/**
 * FORTUNE GAME - Controlador Completo do Jogo em Tela Cheia
 */
(function () {
  const urlParams = new URLSearchParams(window.location.search);
  const gameId = urlParams.get('id') || 'tigre';

  // Informações dos Jogos
  const GAME_INFO = {
    'tigre': { title: 'Fortune Tiger', provider: 'PG Soft', max: '2.500X', img: '/img/tigre.png', symbols: ['wild', 'ingot', 'bag', 'coins', 'firecracker', 'lantern'] },
    'touro': { title: 'Fortune Ox', provider: 'PG Soft', max: '2.000X', img: '/img/touro.png', symbols: ['wild', 'ingot', 'bag', 'coins', 'firecracker', 'bamboo'] },
    'coelho': { title: 'Fortune Rabbit', provider: 'PG Soft', max: '5.000X', img: '/img/coelho.png', symbols: ['wild', 'carrot', 'coins', 'bag', 'lantern', 'bell'] },
    'dragao': { title: 'Fortune Dragon', provider: 'PG Soft', max: '2.500X', img: '/img/dragao.png', symbols: ['wild', 'pearl', 'coins', 'lantern', 'ingot', 'firecracker'] },
    'rato': { title: 'Fortune Mouse', provider: 'PG Soft', max: '1.000X', img: '/img/rato.png', symbols: ['wild', 'cheese', 'bag', 'coins', 'firecracker', 'lantern'] },
    'panda': { title: 'Fortune Panda', provider: 'PG Soft', max: '2.500X', img: '/img/panda.png', symbols: ['wild', 'bamboo', 'coins', 'ingot', 'lantern', 'bell'] },
    'mina-de-ouro': { title: 'Mina de Ouro', provider: 'Mines VIP', max: '10.000X', img: '/img/mina-de-ouro.png' },
    'aviator': { title: 'Aviator Crash', provider: 'Spribe', max: '100.00X', img: '/img/aviator.png' },
    'roleta': { title: 'Roleta Brasileira', provider: 'Evolution', max: '36X', img: '/img/roleta.png', symbols: ['chip', 'bell', 'trophy', 'diamond', 'coins'] },
    'futebol': { title: 'Futebol Studio', provider: 'Evolution', max: '3X', img: '/img/futebol.png', symbols: ['trophy', 'whistle', 'card', 'ball', 'bell'] },
    'bingo-imperial': { title: 'Bingo Imperial', provider: 'Pragmatic Play', max: '500X', img: '/img/bingo-imperial.png', symbols: ['bingoball', 'star', 'trophy', 'coins'] },
    'espaco': { title: 'Spaceman', provider: 'Pragmatic Play', max: '5.000X', img: '/img/espaco.png', symbols: ['planet', 'compass', 'diamond', 'trophy'] }
  };

  const SYMBOL_PAYOUTS = {
    'wild': 25,
    'ingot': 15,
    'trophy': 12,
    'diamond': 10,
    'bag': 8,
    'pearl': 6,
    'coins': 5,
    'money': 4,
    'firecracker': 3,
    'lantern': 2,
    'bell': 2,
    'bamboo': 1.5,
    'carrot': 1.5,
    'cheese': 1.5,
    'planet': 2,
    'bingoball': 2
  };

  let balance = parseFloat(localStorage.getItem('fg_balance') || '50.00');
  let currentBet = 1.00;
  let isSpinning = false;
  let isTurbo = false;
  let isAuto = false;
  let autoInterval = null;

  function formatBRL(val) {
    return 'R$ ' + val.toFixed(2).replace('.', ',');
  }

  function updateBalanceDisplay() {
    const el = document.getElementById('gameBalance');
    if (el) el.textContent = formatBRL(balance);
    localStorage.setItem('fg_balance', balance.toString());
  }

  function updateBetDisplay() {
    const el = document.getElementById('betDisplay');
    if (el) el.textContent = formatBRL(currentBet);
  }

  // Inicialização do Jogo
  function initGame() {
    const game = GAME_INFO[gameId] || GAME_INFO['tigre'];

    // Aplicar título e dados
    document.title = `FortuneGo — ${game.title}`;
    const titleEl = document.getElementById('gameTitle');
    const provEl = document.getElementById('gameProvider');
    const badgeEl = document.getElementById('slotJackpotBadge');
    const bannerImg = document.getElementById('gameBannerImg');

    if (titleEl) titleEl.textContent = game.title;
    if (provEl) provEl.textContent = game.provider;
    if (badgeEl) badgeEl.textContent = `POTENCIAL MÁXIMO ${game.max}`;
    if (bannerImg) bannerImg.src = game.img;

    // Aplicar Tema
    if (window.FortuneTheme) {
      window.FortuneTheme.applyTheme(gameId);
    }

    updateBalanceDisplay();
    updateBetDisplay();

    // Alternar Visualizações dependendo do jogo
    if (gameId === 'mina-de-ouro') {
      document.getElementById('slotGameView').style.display = 'none';
      document.getElementById('minesGameView').style.display = 'block';
      initMines();
    } else if (gameId === 'aviator') {
      document.getElementById('slotGameView').style.display = 'none';
      document.getElementById('crashGameView').style.display = 'block';
      initCrash();
    } else {
      initSlots(game.symbols || ['wild', 'ingot', 'bag', 'coins', 'firecracker', 'lantern']);
    }

    // Botões de aposta
    document.getElementById('btnBetMinus')?.addEventListener('click', () => {
      adjustBet(-0.50);
    });
    document.getElementById('btnBetPlus')?.addEventListener('click', () => {
      adjustBet(0.50);
    });

    // Chips rápidos
    document.querySelectorAll('.quick-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.quick-chip').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentBet = parseFloat(btn.getAttribute('data-bet') || '1.00');
        updateBetDisplay();
        if (window.FortuneAudio) window.FortuneAudio.click();
      });
    });

    // Turbo
    const btnTurbo = document.getElementById('btnTurbo');
    if (btnTurbo) {
      btnTurbo.addEventListener('click', () => {
        isTurbo = !isTurbo;
        btnTurbo.classList.toggle('on', isTurbo);
        if (window.FortuneAudio) window.FortuneAudio.click();
      });
    }

    // Auto
    const btnAuto = document.getElementById('btnAuto');
    if (btnAuto) {
      btnAuto.addEventListener('click', () => {
        isAuto = !isAuto;
        btnAuto.classList.toggle('on', isAuto);
        if (window.FortuneAudio) window.FortuneAudio.click();
        if (isAuto && !isSpinning) {
          spinSlot();
        }
      });
    }

    // Botão de Som
    const btnSound = document.getElementById('gameSoundBtn');
    if (btnSound) {
      btnSound.addEventListener('click', () => {
        if (window.FortuneAudio) {
          const on = window.FortuneAudio.toggleSound();
          btnSound.textContent = on ? '🔊' : '🔇';
        }
      });
    }

    // Botão de Depósito
    document.getElementById('gameDepositBtn')?.addEventListener('click', () => {
      balance += 50.00;
      updateBalanceDisplay();
      if (window.FortuneAudio) window.FortuneAudio.coin();
      alert('Depósito de demonstração de R$ 50,00 adicionado com sucesso!');
    });
  }

  function adjustBet(delta) {
    if (isSpinning) return;
    currentBet = Math.max(0.50, Math.min(50.00, currentBet + delta));
    updateBetDisplay();
    if (window.FortuneAudio) window.FortuneAudio.click();
  }

  // ================== SLOTS SYSTEM ==================
  let activeSymbols = ['wild', 'ingot', 'bag', 'coins', 'firecracker', 'lantern'];

  function initSlots(symbols) {
    activeSymbols = symbols;
    const btnSpin = document.getElementById('btnSpin');
    if (btnSpin) {
      btnSpin.addEventListener('click', spinSlot);
    }
  }

  function spinSlot() {
    if (isSpinning) return;

    if (balance < currentBet) {
      setWinMessage('Saldo insuficiente! Deposite para continuar jogando.', '#f87171');
      if (isAuto) {
        isAuto = false;
        document.getElementById('btnAuto')?.classList.remove('on');
      }
      return;
    }

    isSpinning = true;
    balance -= currentBet;
    updateBalanceDisplay();

    // Incrementar giro nas estatísticas
    let spins = parseInt(localStorage.getItem('fg_spins') || '0', 10) + 1;
    localStorage.setItem('fg_spins', spins.toString());

    setWinMessage('Girando os rolos da sorte... 🍀', '#facc15');
    if (window.FortuneAudio) window.FortuneAudio.spin();

    const btnSpin = document.getElementById('btnSpin');
    if (btnSpin) btnSpin.disabled = true;

    // Remover destaques anteriores
    document.querySelectorAll('.symbol-cell').forEach(c => c.classList.remove('win-highlight'));

    const cols = [
      [document.getElementById('c0-r0'), document.getElementById('c0-r1'), document.getElementById('c0-r2')],
      [document.getElementById('c1-r0'), document.getElementById('c1-r1'), document.getElementById('c1-r2')],
      [document.getElementById('c2-r0'), document.getElementById('c2-r1'), document.getElementById('c2-r2')]
    ];

    const spinIntervals = [];
    cols.forEach(col => {
      const inter = setInterval(() => {
        col.forEach(cell => {
          const randSym = activeSymbols[Math.floor(Math.random() * activeSymbols.length)];
          if (cell) cell.innerHTML = `<img src="/img/sym/${randSym}.png" alt="sym">`;
        });
      }, isTurbo ? 35 : 60);
      spinIntervals.push(inter);
    });

    const baseDelay = isTurbo ? 250 : 500;
    const stepDelay = isTurbo ? 150 : 300;

    // Resultados finais dos rolos
    const finalGrid = [
      ['', '', ''],
      ['', '', ''],
      ['', '', '']
    ];

    cols.forEach((col, colIdx) => {
      setTimeout(() => {
        clearInterval(spinIntervals[colIdx]);
        col.forEach((cell, rowIdx) => {
          let chosen = activeSymbols[Math.floor(Math.random() * activeSymbols.length)];
          // Aumentar emoção da linha do meio
          if (rowIdx === 1 && colIdx === 1 && Math.random() < 0.4) {
            chosen = finalGrid[0][1]; // Repete o primeiro
          } else if (rowIdx === 1 && colIdx === 2 && Math.random() < 0.3) {
            chosen = finalGrid[0][1]; // Linha cheia!
          }
          finalGrid[colIdx][rowIdx] = chosen;
          if (cell) cell.innerHTML = `<img src="/img/sym/${chosen}.png" alt="sym">`;
        });

        if (window.FortuneAudio) window.FortuneAudio.click();

        // Quando o último rolo parar:
        if (colIdx === 2) {
          isSpinning = false;
          if (btnSpin) btnSpin.disabled = false;
          evaluateWin(finalGrid);

          if (isAuto) {
            setTimeout(spinSlot, isTurbo ? 500 : 1000);
          }
        }
      }, baseDelay + (colIdx * stepDelay));
    });
  }

  function evaluateWin(grid) {
    // Linha central
    const s1 = grid[0][1];
    const s2 = grid[1][1];
    const s3 = grid[2][1];

    let won = false;
    let prize = 0;

    if (s1 === s2 && s2 === s3) {
      // 3 iguais na linha principal!
      const mult = SYMBOL_PAYOUTS[s1] || 5;
      prize = currentBet * mult;
      won = true;

      // Destacar células
      document.getElementById('c0-r1')?.classList.add('win-highlight');
      document.getElementById('c1-r1')?.classList.add('win-highlight');
      document.getElementById('c2-r1')?.classList.add('win-highlight');

      setWinMessage(`🎉 GRANDE PRÊMIO! 3x ${s1.toUpperCase()} — Ganhou ${formatBRL(prize)}!`, '#4ade80');
      if (window.FortuneAudio) {
        if (mult >= 10) window.FortuneAudio.bigWin();
        else window.FortuneAudio.win();
      }
    } else if (s1 === s2 || s2 === s3 || s1 === s3) {
      // 2 iguais
      const mult = 0.8;
      prize = currentBet * mult;
      won = true;
      setWinMessage(`✨ Par correspondente! Recuperou ${formatBRL(prize)}`, '#38bdf8');
      if (window.FortuneAudio) window.FortuneAudio.coin();
    } else {
      setWinMessage('Não foi dessa vez! Tente novamente.', '#94a3b8');
    }

    if (won) {
      balance += prize;
      updateBalanceDisplay();

      let wins = parseInt(localStorage.getItem('fg_wins') || '0', 10) + 1;
      localStorage.setItem('fg_wins', wins.toString());

      let best = parseFloat(localStorage.getItem('fg_best') || '0');
      if (prize > best) {
        localStorage.setItem('fg_best', prize.toString());
      }
    }
  }

  function setWinMessage(text, color = '#facc15') {
    const el = document.getElementById('winMessage');
    if (el) {
      el.textContent = text;
      el.style.color = color;
    }
  }

  // ================== MINES SYSTEM ==================
  function initMines() {
    const grid = document.getElementById('minesGrid');
    if (!grid) return;
    grid.innerHTML = '';
    for (let i = 0; i < 25; i++) {
      const cell = document.createElement('div');
      cell.className = 'mine-cell';
      cell.textContent = '❓';
      cell.onclick = () => {
        cell.classList.add('revealed');
        if (Math.random() < 0.2) {
          cell.textContent = '💣';
          cell.style.borderColor = '#ef4444';
          if (window.FortuneAudio) window.FortuneAudio.vibrate([100, 100]);
          alert('BOMBA! Fim de jogo.');
          initMines();
        } else {
          cell.textContent = '💎';
          cell.style.borderColor = '#38bdf8';
          balance += currentBet * 0.4;
          updateBalanceDisplay();
          if (window.FortuneAudio) window.FortuneAudio.coin();
        }
      };
      grid.appendChild(cell);
    }
  }

  // ================== CRASH / AVIATOR SYSTEM ==================
  function initCrash() {
    let mult = 1.00;
    const multEl = document.getElementById('crashMultiplier');
    const planeEl = document.getElementById('crashPlane');

    setInterval(() => {
      mult += 0.05;
      if (multEl) multEl.textContent = mult.toFixed(2) + 'x';
      if (planeEl) {
        const x = Math.min(220, (mult - 1) * 35);
        const y = Math.min(100, (mult - 1) * 20);
        planeEl.style.transform = `translate(${x}px, -${y}px)`;
      }
      if (mult > 3.5 && Math.random() < 0.15) {
        mult = 1.00;
        if (multEl) multEl.textContent = 'CRASH!';
      }
    }, 150);
  }

  window.addEventListener('DOMContentLoaded', initGame);
})();
